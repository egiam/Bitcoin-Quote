# Display de cotización de Bitcoin
Un display de la cotización de bitcoin en tiempo real usando la API de Coindesk

<img src="https://i.ibb.co/7ytjBW7/Screen-Shot-2021-04-20-at-22-26-05.png" alt="memo" width="400"/>

**App desarrollada en este tutorial:** https://youtu.be/xUwkGVin9-8

Tecnologías:
- HTML
- CSS
- JavaScript
